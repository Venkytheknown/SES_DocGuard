# Contents of /SES-DocGuard/SES-DocGuard/src/evaluator/__init__.py

# This file is intentionally left blank.